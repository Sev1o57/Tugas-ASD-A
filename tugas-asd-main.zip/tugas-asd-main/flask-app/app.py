"""API Flask untuk simulator linked list.

Jalankan dengan:
    python app.py
lalu buka http://127.0.0.1:5000
"""

from flask import Flask, jsonify, render_template, request

from linkedlist import LinkedList

app = Flask(__name__)
ll = LinkedList()


@app.route("/")
def index():
    return render_template("index.html", list=ll.to_list())


@app.route("/api/list", methods=["GET"])
def get_list():
    return jsonify({"list": ll.to_list()})


@app.route("/api/insert", methods=["POST"])
def insert():
    data = request.get_json()
    op = data.get("op")  # head | tail | at
    value = data.get("value")

    if op == "head":
        ll.insert_head(value)
    elif op == "tail":
        ll.insert_tail(value)
    elif op == "at":
        try:
            ll.insert_at(int(data.get("index", 0)), value)
        except IndexError:
            return jsonify({"error": "index di luar jangkauan"}), 400
    else:
        return jsonify({"error": "op tidak dikenal"}), 400

    return jsonify({"list": ll.to_list()})


@app.route("/api/delete", methods=["POST"])
def delete():
    value = request.get_json().get("value")
    if ll.delete(value):
        return jsonify({"list": ll.to_list()})
    return jsonify({"error": "value tidak ditemukan"}), 404


@app.route("/api/search", methods=["POST"])
def search():
    value = request.get_json().get("value")
    found = ll.search(value)
    return jsonify({"found": found, "list": ll.to_list()})


@app.route("/api/reverse", methods=["POST"])
def reverse():
    ll.reverse()
    return jsonify({"list": ll.to_list()})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
