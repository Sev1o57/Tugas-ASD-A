"""Singly Linked List - tugas Algoritma & Struktur Data.

Setiap node menyimpan data dan pointer ke node berikutnya.
Head adalah titik masuk satu-satunya ke dalam list.
"""


class Node:
    """Satu simpul: [ data | next ]"""

    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    """Singly Linked List dengan operasi dasar O(1) dan O(n)."""

    def __init__(self):
        self.head = None

    def insert_head(self, data):
        """Sisip di depan - O(1)."""
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def insert_tail(self, data):
        """Sisip di belakang - O(n) karena harus menelusuri seluruh list."""
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    def insert_at(self, index, data):
        """Sisip pada posisi tertentu - O(n)."""
        if index == 0:
            self.insert_head(data)
            return
        prev = self.head
        for _ in range(index - 1):
            if prev is None:
                raise IndexError("index di luar jangkauan")
            prev = prev.next
        if prev is None:
            raise IndexError("index di luar jangkauan")
        new_node = Node(data)
        new_node.next = prev.next
        prev.next = new_node

    def delete(self, data):
        """Hapus node pertama yang bernilai data. Return True jika berhasil."""
        if self.head is None:
            return False
        if self.head.data == data:
            self.head = self.head.next
            return True
        prev, current = self.head, self.head.next
        while current:
            if current.data == data:
                prev.next = current.next
                return True
            prev, current = current, current.next
        return False

    def search(self, data):
        """Cari data, return True/False - O(n)."""
        current = self.head
        while current:
            if current.data == data:
                return True
            current = current.next
        return False

    def reverse(self):
        """Balik arah seluruh pointer - O(n)."""
        prev, current = None, self.head
        while current:
            next_node = current.next
            current.next = prev
            prev, current = current, next_node
        self.head = prev

    def to_list(self):
        """Ubah menjadi list Python biasa (untuk respons JSON)."""
        current, out = self.head, []
        while current:
            out.append(current.data)
            current = current.next
        return out

    def __len__(self):
        return len(self.to_list())
