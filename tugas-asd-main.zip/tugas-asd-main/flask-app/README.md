# ASD Project — Simulator Linked List (Flask + Python)

Tugas mata kuliah **Algoritma & Struktur Data**.
Aplikasi web kecil untuk mendemonstrasikan operasi *singly linked list*:
insert head, insert tail, insert at, delete, search, dan reverse.

## Struktur Proyek

```
flask-app/
├── app.py               # Server Flask + REST API
├── linkedlist.py        # Implementasi LinkedList (Node, insert, delete, ...)
├── requirements.txt     # Dependensi
├── README.md
└── templates/
    └── index.html       # Halaman demo (HTML/CSS/JS murni, tanpa framework)
```

## Cara Menjalankan

```bash
cd flask-app
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Buka **http://127.0.0.1:5000** di browser.

## Endpoint API

| Method | Endpoint      | Body JSON                                | Keterangan            |
|--------|---------------|------------------------------------------|-----------------------|
| GET    | `/api/list`   | -                                        | Ambil isi list        |
| POST   | `/api/insert` | `{"op": "head"\|"tail"\|"at", "value": 7, "index": 2}` | Sisip node |
| POST   | `/api/delete` | `{"value": 7}`                           | Hapus node pertama yang cocok |
| POST   | `/api/search` | `{"value": 7}`                           | Cari nilai            |
| POST   | `/api/reverse`| -                                        | Balik arah list       |

## Kompleksitas Operasi

| Operasi      | Kompleksitas | Alasan                                   |
|--------------|--------------|------------------------------------------|
| insert_head  | O(1)         | Cukup ubah pointer head                  |
| insert_tail  | O(n)         | Harus menelusuri sampai node terakhir    |
| insert_at    | O(n)         | Menelusuri sampai posisi index           |
| delete       | O(n)         | Menelusuri sampai node yang dicocokkan   |
| search       | O(n)         | Menelusuri satu per satu                 |
| reverse      | O(n)         | Membalik pointer sekali jalan            |

## Catatan

- Visualizer interaktif versi web (React) ada di aplikasi utama proyek ini.
  Logika animasinya di `src/lib/linkedList.ts` sengaja dibuat mengikuti
  alur langkah `linkedlist.py`, sehingga keduanya bisa dipakai berdampingan
  saat presentasi.
