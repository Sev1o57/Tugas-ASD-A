import { useCallback, useEffect, useRef, useState } from "react";
import {
  deleteValue,
  insertAt,
  insertHead,
  insertTail,
  reverse,
  search,
  type Frame,
  type FrameNode,
} from "@/lib/linkedList";

export type OpKind =
  | "insertHead"
  | "insertTail"
  | "insertAt"
  | "delete"
  | "search"
  | "reverse";

export interface LogEntry {
  id: number;
  text: string;
  tone: "info" | "success" | "error";
}

const INITIAL_VALUES = [7, 13, 42];
const toNodes = (values: number[]): FrameNode[] =>
  values.map((v) => ({ id: `seed-${v}-${Math.random().toString(36).slice(2, 7)}`, value: v, state: "idle" as const }));

export function useLinkedListSimulator() {
  const [nodes, setNodes] = useState<FrameNode[]>(() => toNodes(INITIAL_VALUES));
  const [frames, setFrames] = useState<Frame[]>([]);
  const [cursor, setCursor] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [opCount, setOpCount] = useState(0);

  const historyRef = useRef<FrameNode[][]>([]);
  const logIdRef = useRef(0);
  const playingRef = useRef(false);
  playingRef.current = playing;

  const addLog = useCallback((text: string, tone: LogEntry["tone"] = "info") => {
    setLog((prev) => {
      const next = [...prev, { id: ++logIdRef.current, text, tone }];
      return next.length > 120 ? next.slice(next.length - 120) : next;
    });
  }, []);

  const runOp = useCallback(
    (kind: OpKind, value?: number, index?: number) => {
      if (playingRef.current) return;

      const mutating = kind !== "search";
      let result;
      switch (kind) {
        case "insertHead":
          if (value === undefined) return;
          result = insertHead(nodes, value);
          break;
        case "insertTail":
          if (value === undefined) return;
          result = insertTail(nodes, value);
          break;
        case "insertAt":
          if (value === undefined || index === undefined) return;
          result = insertAt(nodes, value, index);
          break;
        case "delete":
          if (value === undefined) return;
          result = deleteValue(nodes, value);
          break;
        case "search":
          if (value === undefined) return;
          result = search(nodes, value);
          break;
        case "reverse":
          result = reverse(nodes);
          break;
      }

      if (mutating && result.ok) {
        historyRef.current = [...historyRef.current.slice(-29), nodes];
      }

      addLog(`▸ ${result.summary}`, result.ok ? "success" : "error");
      setOpCount((c) => c + 1);
      setFrames(result.frames);
      setCursor(0);
      setPlaying(result.frames.length > 1);
    },
    [nodes, addLog],
  );

  const stepForward = useCallback(() => {
    setPlaying(false);
    setCursor((c) => Math.min(c + 1, Math.max(frames.length - 1, 0)));
  }, [frames.length]);

  const stepBack = useCallback(() => {
    setPlaying(false);
    setCursor((c) => Math.max(c - 1, 0));
  }, []);

  const togglePlay = useCallback(() => {
    if (frames.length === 0) return;
    setPlaying((p) => {
      if (!p && cursor >= frames.length - 1) {
        setCursor(0);
        return true;
      }
      return !p;
    });
  }, [frames.length, cursor]);

  const undo = useCallback(() => {
    if (playingRef.current || historyRef.current.length === 0) return;
    const prev = historyRef.current[historyRef.current.length - 1];
    historyRef.current = historyRef.current.slice(0, -1);
    setFrames([]);
    setCursor(0);
    setNodes(prev);
    addLog("↩ Operasi terakhir dibatalkan.", "info");
  }, [addLog]);

  const reset = useCallback(() => {
    historyRef.current = [];
    setFrames([]);
    setCursor(0);
    setPlaying(false);
    setNodes(toNodes(INITIAL_VALUES));
    addLog("⟳ Simulator direset ke contoh awal [7, 13, 42].", "info");
  }, [addLog]);

  const clearAll = useCallback(() => {
    historyRef.current = [];
    setFrames([]);
    setCursor(0);
    setPlaying(false);
    setNodes([]);
    addLog("∅ List dikosongkan.", "info");
  }, [addLog]);

  // Autoplay: satu frame per langkah dengan jarak waktu sesuai kecepatan.
  useEffect(() => {
    if (!playing || frames.length === 0) return;
    if (cursor >= frames.length - 1) {
      setPlaying(false);
      return;
    }
    const t = setTimeout(() => setCursor((c) => c + 1), 1400 / speed);
    return () => clearTimeout(t);
  }, [playing, cursor, frames.length, speed]);

  // Saat animasi selesai: commit state akhir + tulis ringkasan ke log.
  useEffect(() => {
    if (playing || frames.length === 0) return;
    if (cursor !== frames.length - 1) return;
    const last = frames[frames.length - 1];
    setNodes((prev) => {
      const final = last.nodes.map((n) => ({ ...n, state: "idle" as const }));
      // Hindari state update berulang dengan perbandingan id di posisi sama.
      if (
        prev.length === final.length &&
        prev.every((n, i) => n.id === final[i].id && n.value === final[i].value)
      ) {
        return prev;
      }
      return final;
    });
  }, [playing, cursor, frames]);

  // Log narasi frame yang sedang ditampilkan.
  useEffect(() => {
    if (frames.length === 0) return;
    const frame = frames[cursor];
    if (!frame) return;
    addLog(frame.message);
  }, [cursor, frames, addLog]);

  const displayNodes: FrameNode[] = frames.length
    ? frames[Math.min(cursor, frames.length - 1)].nodes
    : nodes;
  const currentFrame: Frame | null = frames.length
    ? frames[Math.min(cursor, frames.length - 1)]
    : null;
  const hasFinished = frames.length > 0 && cursor >= frames.length - 1;

  return {
    nodes,
    displayNodes,
    currentFrame,
    cursor,
    totalFrames: frames.length,
    playing,
    hasFinished,
    speed,
    setSpeed,
    log,
    opCount,
    canUndo: historyRef.current.length > 0,
    runOp,
    stepForward,
    stepBack,
    togglePlay,
    undo,
    reset,
    clearAll,
  };
}
