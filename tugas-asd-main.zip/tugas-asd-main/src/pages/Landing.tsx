import { motion } from "framer-motion";
import {
  ArrowRight,
  Clock,
  FlaskConical,
  Layers,
  MousePointerClick,
  Play,
  RotateCcw,
  Search,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router";

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-60px" },
  transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] as const },
};

const OPERATIONS = [
  {
    icon: Layers,
    name: "insert_head · insert_tail",
    bigo: "O(1) · O(n)",
    desc: "Node baru mengambil alih head, atau menelusuri seluruh list hingga ekor.",
  },
  {
    icon: Search,
    name: "search",
    bigo: "O(n)",
    desc: "Membandingkan data satu per satu mulai dari head sampai None.",
  },
  {
    icon: Trash2,
    name: "delete",
    bigo: "O(n)",
    desc: "Pointer prev melewati node yang dicocokkan, lalu node dilepas dari rantai.",
  },
  {
    icon: RotateCcw,
    name: "reverse",
    bigo: "O(n)",
    desc: "Setiap pointer next dibalik arahnya dalam satu kali penelusuran.",
  },
];

const CONCEPTS = [
  {
    title: "Node = [data | next]",
    body: "Satu simpul menyimpan nilai dan alamat node berikutnya. Tidak ada indeks fisik di memori — hanya rantai pointer.",
  },
  {
    title: "Head sebagai satu-satunya pintu masuk",
    body: "Seluruh list hanya dapat diakses dari head. Kehilangan referensi head berarti kehilangan seluruh data.",
  },
  {
    title: "None sebagai penanda akhir",
    body: "Node terakhir menunjuk None — batas resmi akhir dari sebuah rantai.",
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <header className="mx-auto flex w-full max-w-5xl items-center justify-between px-4 pt-6 sm:px-6">
        <div className="flex items-center gap-2.5">
          <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-clay-primary">
            <span className="text-sm font-semibold">A</span>
          </div>
          <span className="text-base font-semibold tracking-tight">ASD Project</span>
        </div>
        <nav className="hidden items-center gap-7 text-sm font-medium text-muted-foreground md:flex">
          <a href="#konsep" className="transition-colors hover:text-foreground">Konsep</a>
          <a href="#operasi" className="transition-colors hover:text-foreground">Operasi</a>
          <a href="#flask" className="transition-colors hover:text-foreground">Flask</a>
        </nav>
        <Button asChild className="rounded-lg shadow-clay-primary">
          <Link to="/dashboard">
            Masuk <ArrowRight className="size-4" />
          </Link>
        </Button>
      </header>

      <main>
        {/* Hero */}
        <section className="mx-auto w-full max-w-5xl px-4 pt-16 pb-20 sm:px-6 lg:pt-24">
          <div className="grid items-center gap-14 lg:grid-cols-[1.1fr_1fr]">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            >
              <span className="inline-flex items-center gap-2 rounded-full border bg-card px-3.5 py-1.5 text-xs font-medium text-muted-foreground shadow-clay-xs">
                <FlaskConical className="size-3.5 text-primary" />
                Tugas Algoritma &amp; Struktur Data
              </span>
              <h1 className="mt-6 text-4xl leading-[1.1] font-semibold tracking-tight text-balance sm:text-5xl">
                Memahami{" "}
                <span className="relative inline-block">
                  <span className="text-primary">linked list</span>
                  <span className="absolute inset-x-0 bottom-0.5 -z-10 h-3 bg-primary/10" />
                </span>{" "}
                melalui visualisasi langkah demi langkah.
              </h1>
              <p className="mt-5 max-w-lg text-base leading-7 text-muted-foreground sm:text-lg">
                ASD Project adalah simulator interaktif untuk mata kuliah Algoritma
                dan Struktur Data. Setiap operasi — sisip, cari, hapus, dan balik —
                diurai menjadi frame kecil, lengkap dengan pseudocode Python yang
                ikut ter-highlight pada baris yang sedang dieksekusi.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Button
                  asChild
                  size="lg"
                  className="rounded-lg shadow-clay-primary"
                >
                  <Link to="/dashboard">
                    <Play className="size-4" /> Buka Simulator
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="rounded-lg bg-card shadow-clay-sm"
                >
                  <a href="#flask">
                    <FlaskConical className="size-4 text-primary" /> Kode Backend Flask
                  </a>
                </Button>
              </div>
              <p className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
                <MousePointerClick className="size-3.5" />
                Berjalan sepenuhnya di peramban — tidak perlu instalasi apa pun.
              </p>
            </motion.div>

            {/* Ilustrasi list */}
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 18 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.65, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="rounded-2xl border bg-card p-6 shadow-clay sm:p-7">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
                    head
                  </p>
                  <span className="rounded-md bg-chart-4/15 px-2 py-0.5 font-mono text-[10px] font-semibold text-foreground">
                    insert_head · O(1)
                  </span>
                </div>
                <div className="mt-5 flex items-center gap-3">
                  {[
                    { v: 7, cls: "border-border/60 bg-card text-foreground" },
                    { v: 13, cls: "border-amber-300/70 bg-chart-3/25 text-foreground ring-2 ring-chart-3/40" },
                    { v: 42, cls: "border-primary/40 bg-primary text-primary-foreground" },
                  ].map((n) => (
                    <div key={n.v} className="flex items-center gap-3">
                      <div className={`flex flex-col items-center rounded-lg border px-3.5 py-2.5 ${n.cls}`}>
                        <span className="text-lg leading-none font-semibold tabular-nums">{n.v}</span>
                        <span className="mt-1 text-[9px] opacity-70">node</span>
                      </div>
                      <span className="text-muted-foreground/70">→</span>
                    </div>
                  ))}
                  <div className="flex flex-col items-center rounded-lg border border-dashed border-border bg-secondary px-3 py-3">
                    <span className="text-xs font-medium text-muted-foreground">NULL</span>
                  </div>
                </div>
                <div className="mt-6 rounded-lg border bg-secondary/60 px-4 py-3 font-mono text-[12px] leading-6">
                  <p className="text-muted-foreground">
                    new_node = Node(<span className="text-foreground font-semibold">42</span>)
                  </p>
                  <p className="text-muted-foreground">
                    new_node.next = self.head
                  </p>
                  <p className="font-semibold text-primary">self.head = new_node</p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Konsep */}
        <section id="konsep" className="border-t bg-card/50">
          <div className="mx-auto w-full max-w-5xl px-4 py-16 sm:px-6">
            <motion.div {...fadeUp}>
              <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
                Landasan teori
              </p>
              <h2 className="mt-3 text-2xl font-semibold tracking-tight sm:text-3xl">
                Tiga konsep inti linked list
              </h2>
              <p className="mt-2 max-w-xl text-muted-foreground">
                Ringkasan singkat sebelum masuk ke implementasi kode.
              </p>
            </motion.div>
            <div className="mt-10 grid gap-px overflow-hidden rounded-2xl border bg-border md:grid-cols-3">
              {CONCEPTS.map((c, i) => (
                <motion.div
                  key={c.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                  className="bg-card p-6"
                >
                  <span className="font-mono text-xs text-muted-foreground">
                    0{i + 1}
                  </span>
                  <h3 className="mt-3 font-semibold">{c.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-muted-foreground">{c.body}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Operasi */}
        <section id="operasi" className="mx-auto w-full max-w-5xl px-4 py-16 sm:px-6">
          <motion.div {...fadeUp}>
            <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Implementasi
            </p>
            <h2 className="mt-3 text-2xl font-semibold tracking-tight sm:text-3xl">
              Enam operasi, satu tampilan langkah
            </h2>
            <p className="mt-2 max-w-xl text-muted-foreground">
              Setiap operasi dipecah menjadi frame kecil: node mana yang aktif,
              pointer mana yang bergeser, dan baris pseudocode yang sedang berjalan.
            </p>
          </motion.div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2">
            {OPERATIONS.map((op, i) => (
              <motion.div
                key={op.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: (i % 2) * 0.08, ease: [0.22, 1, 0.36, 1] }}
                className="flex items-start gap-4 rounded-xl border bg-card p-5 shadow-clay-sm"
              >
                <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <op.icon className="size-4.5" />
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-mono text-sm font-semibold">{op.name}</h3>
                    <span className="rounded bg-chart-4/15 px-1.5 py-0.5 font-mono text-[10px] font-semibold">
                      {op.bigo}
                    </span>
                  </div>
                  <p className="mt-1.5 text-sm leading-6 text-muted-foreground">{op.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Flask */}
        <section id="flask" className="border-t bg-card/50">
          <div className="mx-auto w-full max-w-5xl px-4 py-16 sm:px-6">
            <motion.div
              {...fadeUp}
              className="grid items-center gap-10 lg:grid-cols-[1.15fr_1fr]"
            >
              <div>
                <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
                  Backend
                </p>
                <h2 className="mt-3 text-2xl font-semibold tracking-tight sm:text-3xl">
                  Proyek Flask siap dijalankan dan dikumpulkan
                </h2>
                <p className="mt-3 max-w-lg leading-7 text-muted-foreground">
                  Kode yang ditampilkan di simulator identik dengan berkas pada
                  folder{" "}
                  <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-[12px]">flask-app/</code>
                  {" "}— sebuah REST API dengan endpoint{" "}
                  <code className="font-mono text-[12px]">/api/insert</code>,{" "}
                  <code className="font-mono text-[12px]">/api/delete</code>,{" "}
                  <code className="font-mono text-[12px]">/api/search</code>, dan{" "}
                  <code className="font-mono text-[12px]">/api/reverse</code>, serta
                  halaman demo HTML murni. Jalankan{" "}
                  <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-[12px]">python app.py</code>{" "}
                  lalu buka localhost:5000 untuk demo langsung di kelas.
                </p>
                <div className="mt-7 flex flex-wrap gap-3">
                  <Button asChild className="rounded-lg shadow-clay-primary">
                    <Link to="/dashboard">
                      Lihat Kode di Simulator <ArrowRight className="size-4" />
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="rounded-xl bg-[#1e2230] p-5 font-mono text-[12px] leading-6 shadow-clay">
                <p className="text-white/35"># flask-app/linkedlist.py</p>
                <p className="text-[#9fb8ff]">def insert_head(self, data):</p>
                <p className="pl-4 text-[#d6dae6]">new_node = Node(data)</p>
                <p className="pl-4 text-[#d6dae6]">new_node.next = self.head</p>
                <p className="pl-4 text-[#9fb8ff]">self.head = new_node</p>
                <p className="mt-2 text-white/35"># O(1) — tanpa traversal</p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* CTA akhir */}
        <section className="mx-auto w-full max-w-5xl px-4 py-20 text-center sm:px-6">
          <motion.div {...fadeUp}>
            <Clock className="mx-auto size-5 text-primary" />
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Struktur data paling mudah dipahami saat dilihat bergerak.
            </h2>
            <p className="mx-auto mt-3 max-w-md text-muted-foreground">
              Masuk dengan email atau sebagai tamu, jalankan operasi apa saja,
              dan amati bagaimana setiap pointer berpindah.
            </p>
            <Button asChild size="lg" className="mt-8 rounded-lg shadow-clay-primary">
              <Link to="/dashboard">
                Mulai Simulasi <ArrowRight className="size-4" />
              </Link>
            </Button>
          </motion.div>
        </section>
      </main>

      <footer className="border-t py-6 text-center text-xs text-muted-foreground">
        ASD Project — Tugas Mata Kuliah Algoritma &amp; Struktur Data ·
        Dibangun dengan React dan Flask
      </footer>
    </div>
  );
}
