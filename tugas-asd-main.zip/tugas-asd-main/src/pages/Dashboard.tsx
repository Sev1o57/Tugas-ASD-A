import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Code2, LogOut } from "lucide-react";
import { Link, useNavigate } from "react-router";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useLinkedListSimulator } from "@/hooks/use-linked-list-simulator";
import { ArrowLink, HeadTag, NodeChip, NullTag } from "@/components/simulator/NodeChip";
import { LogPanel, PseudocodePanel } from "@/components/simulator/Panels";
import { Toolbar } from "@/components/simulator/Toolbar";
import { ComplexityPanel } from "@/components/simulator/ComplexityPanel";
import { CodeDialog } from "@/components/simulator/CodeDialog";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [codeOpen, setCodeOpen] = useState(false);
  const sim = useLinkedListSimulator();

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  return (
    <main className="min-h-screen bg-background px-4 py-8 text-foreground sm:px-6 lg:px-8">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-6">
        {/* Header */}
        <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3.5">
            <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-clay-primary">
              <span className="text-base font-semibold">A</span>
            </div>
            <div>
              <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
                ASD Project · Algoritma &amp; Struktur Data
              </p>
              <h1 className="text-xl font-semibold tracking-tight">
                Dasbor Simulator Linked List
                {user?.name ? (
                  <span className="font-normal text-muted-foreground"> — {user.name}</span>
                ) : null}
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              className="rounded-lg bg-card shadow-clay-xs"
              onClick={() => setCodeOpen(true)}
            >
              <Code2 className="size-4" /> Kode Python
            </Button>
            <Button
              variant="outline"
              className="rounded-lg bg-card shadow-clay-xs"
              onClick={handleSignOut}
            >
              <LogOut className="size-4" /> Keluar
            </Button>
          </div>
        </header>

        {/* Toolbar */}
        <section className="rounded-2xl border bg-card p-4 shadow-clay sm:p-5">
          <Toolbar
            onRun={sim.runOp}
            playing={sim.playing}
            cursor={sim.cursor}
            totalFrames={sim.totalFrames}
            speed={sim.speed}
            onSpeedChange={sim.setSpeed}
            onTogglePlay={sim.togglePlay}
            onStepForward={sim.stepForward}
            onStepBack={sim.stepBack}
            canUndo={sim.canUndo}
            onUndo={sim.undo}
            onReset={sim.reset}
            onClear={sim.clearAll}
            onShowCode={() => setCodeOpen(true)}
          />
        </section>

        {/* Visualizer */}
        <section className="relative overflow-hidden rounded-2xl border bg-card p-5 shadow-clay sm:p-7">
          <div className="relative flex min-h-36 flex-wrap items-center gap-x-2.5 gap-y-8 py-3">
            {sim.displayNodes.length === 0 ? (
              <div className="flex items-center gap-2.5">
                <HeadTag />
                <span className="rounded-lg border border-dashed bg-secondary px-4 py-3 text-sm font-medium text-muted-foreground">
                  head = None — list masih kosong, sisipkan node untuk memulai.
                </span>
                <NullTag />
              </div>
            ) : (
              <>
                <HeadTag />
                <AnimatePresence mode="popLayout" initial={false}>
                  {sim.displayNodes.map((node, i) => (
                    <div key={node.id} className="contents">
                      <NodeChip node={node} index={i} />
                      <ArrowLink />
                    </div>
                  ))}
                </AnimatePresence>
                <NullTag />
              </>
            )}
          </div>

          {/* Narasi frame aktif */}
          <div className="mt-2 flex items-start gap-3 rounded-xl border bg-secondary/60 px-4 py-3">
            <p className="text-sm leading-6 text-foreground/90">
              {sim.currentFrame
                ? sim.currentFrame.message
                : "Jalankan salah satu operasi untuk melihat animasi langkah demi langkah — dari pembuatan node hingga penggeseran pointer."}
            </p>
          </div>
        </section>

        {/* Panels */}
        <section className="grid gap-5 lg:grid-cols-3">
          <div className="min-h-72 rounded-2xl border bg-card shadow-clay">
            <PseudocodePanel frame={sim.currentFrame} />
          </div>
          <div className="min-h-72 rounded-2xl border bg-card shadow-clay">
            <LogPanel entries={sim.log} />
          </div>
          <div className="min-h-72 rounded-2xl border bg-card shadow-clay">
            <ComplexityPanel />
          </div>
        </section>

        <footer className="flex flex-wrap items-center justify-center gap-1.5 pb-4 text-center text-xs text-muted-foreground">
          <span>Logika animasi mengikuti implementasi</span>
          <code className="rounded bg-muted px-1.5 py-0.5 font-mono">flask-app/linkedlist.py</code>
          <span>—</span>
          <Link
            to="/"
            className="font-medium underline-offset-2 hover:underline"
          >
            kembali ke ringkasan proyek
          </Link>
        </footer>
      </div>

      <CodeDialog open={codeOpen} onOpenChange={setCodeOpen} />
    </main>
  );
}
