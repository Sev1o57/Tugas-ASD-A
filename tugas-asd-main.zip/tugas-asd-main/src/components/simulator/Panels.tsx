import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import type { Frame } from "@/lib/linkedList";
import { PSEUDOCODE } from "@/lib/linkedList";
import type { LogEntry } from "@/hooks/use-linked-list-simulator";

export function PseudocodePanel({ frame }: { frame: Frame | null }) {
  const activeRef = useRef<HTMLLIElement | null>(null);

  const block = frame
    ? PSEUDOCODE.find((b) => b.fn === frame.fn)
    : undefined;

  useEffect(() => {
    activeRef.current?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [frame?.fn, frame?.line]);

  if (!block) {
    return (
      <div className="flex h-full flex-col">
        <div className="flex items-center justify-between px-5 pt-4">
          <h3 className="text-sm font-semibold">Pseudocode</h3>
          <span className="rounded-full border bg-muted px-2.5 py-0.5 text-[10px] font-medium text-muted-foreground">
            python
          </span>
        </div>
        <div className="flex flex-1 items-center justify-center px-6 pb-6 text-center text-sm text-muted-foreground">
          Jalankan salah satu operasi untuk melihat pseudocode yang sedang
          dieksekusi baris demi baris.
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between px-5 pt-4">
        <h3 className="text-sm font-semibold">Pseudocode</h3>
        <span className="rounded-full border bg-secondary px-2.5 py-0.5 font-mono text-[10px] font-medium text-secondary-foreground">
          {block.label}
        </span>
      </div>
      <ol className="flex-1 overflow-y-auto px-5 pt-3 pb-5 font-mono text-[12px] leading-6">
        {block.code.map((code, i) => {
          const line = i + 1;
          const active = line === frame!.line;
          return (
            <li
              key={line}
              ref={active ? activeRef : undefined}
              className={cn(
                "flex gap-3 rounded-lg px-2 transition-colors duration-200",
                active
                  ? "bg-primary/10 font-semibold text-foreground ring-1 ring-primary/25"
                  : "text-muted-foreground",
              )}
            >
              <span
                className={cn(
                  "w-4 shrink-0 text-right tabular-nums",
                  active ? "text-primary" : "opacity-50",
                )}
              >
                {line}
              </span>
              <code className="whitespace-pre">{code}</code>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

export function LogPanel({ entries }: { entries: LogEntry[] }) {
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [entries.length]);

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between px-5 pt-4">
        <h3 className="text-sm font-semibold">Log Eksekusi</h3>
        <span className="rounded-full border bg-muted px-2.5 py-0.5 text-[10px] font-medium text-muted-foreground">
          {entries.length} baris
        </span>
      </div>
      <div className="flex-1 overflow-y-auto px-5 pt-3 pb-5">
        {entries.length === 0 ? (
          <p className="pt-2 text-sm text-muted-foreground">
            Belum ada operasi. Coba sisip node atau cari nilai untuk mulai.
          </p>
        ) : (
          <ul className="space-y-1.5 text-[12px] leading-5">
            {entries.map((e) => (
              <li
                key={e.id}
                className={cn(
                  "rounded-lg border px-2.5 py-1.5 font-mono",
                  e.tone === "success" &&
                    "border-emerald-200/70 bg-chart-4/10 font-medium text-foreground",
                  e.tone === "error" &&
                    "border-destructive/25 bg-destructive/10 font-medium text-destructive",
                  e.tone === "info" && "border-transparent bg-muted/60 text-muted-foreground",
                )}
              >
                {e.text}
              </li>
            ))}
          </ul>
        )}
        <div ref={endRef} />
      </div>
    </div>
  );
}
