import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import type { OpKind } from "@/hooks/use-linked-list-simulator";
import {
  ChevronsLeft,
  Eye,
  Layers,
  Pause,
  Play,
  RotateCcw,
  Save,
  Search,
  SkipBack,
  SkipForward,
  Trash2,
  Undo2,
} from "lucide-react";

interface ToolbarProps {
  onRun: (kind: OpKind, value?: number, index?: number) => void;
  playing: boolean;
  cursor: number;
  totalFrames: number;
  speed: number;
  onSpeedChange: (v: number) => void;
  onTogglePlay: () => void;
  onStepForward: () => void;
  onStepBack: () => void;
  canUndo: boolean;
  onUndo: () => void;
  onReset: () => void;
  onClear: () => void;
  onShowCode: () => void;
  className?: string;
}

const opButton =
  "rounded-lg shadow-clay-xs clay-press font-semibold text-xs sm:text-sm h-10";

export function Toolbar({
  onRun,
  playing,
  cursor,
  totalFrames,
  speed,
  onSpeedChange,
  onTogglePlay,
  onStepForward,
  onStepBack,
  canUndo,
  onUndo,
  onReset,
  onClear,
  onShowCode,
  className,
}: ToolbarProps) {
  const [value, setValue] = useState("");
  const [index, setIndex] = useState("");

  const parsedValue = () => {
    const v = Number.parseInt(value, 10);
    return Number.isNaN(v) ? undefined : v;
  };
  const parsedIndex = () => {
    const i = Number.parseInt(index, 10);
    return Number.isNaN(i) ? undefined : i;
  };

  const guard = (fn: () => void) => {
    if (playing) return;
    fn();
  };

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      {/* Baris 1: input + operasi utama */}
      <div className="flex flex-wrap items-center gap-2.5">
        <Input
          value={value}
          onChange={(e) => setValue(e.target.value.replace(/[^0-9-]/g, ""))}
          placeholder="Nilai…"
          inputMode="numeric"
          className="h-10 w-24 rounded-lg bg-card shadow-clay-inset text-center font-semibold"
          aria-label="Nilai node"
        />
        <Input
          value={index}
          onChange={(e) => setIndex(e.target.value.replace(/[^0-9]/g, ""))}
          placeholder="Index…"
          inputMode="numeric"
          className="h-10 w-24 rounded-lg bg-card shadow-clay-inset text-center font-semibold"
          aria-label="Index untuk sisip di posisi"
        />

        <Button
          className={cn(opButton, "bg-primary text-primary-foreground hover:bg-primary/90")}
          onClick={() =>
            guard(() => {
              const v = parsedValue();
              if (v === undefined) return;
              onRun("insertHead", v);
            })
          }
          disabled={playing}
        >
          <Save className="size-3.5" /> Sisip Head
        </Button>
        <Button
          className={cn(opButton, "bg-primary text-primary-foreground hover:bg-primary/90")}
          onClick={() =>
            guard(() => {
              const v = parsedValue();
              if (v === undefined) return;
              onRun("insertTail", v);
            })
          }
          disabled={playing}
        >
          <Layers className="size-3.5" /> Sisip Tail
        </Button>
        <Button
          className={cn(opButton, "bg-primary text-primary-foreground hover:bg-primary/90")}
          onClick={() =>
            guard(() => {
              const v = parsedValue();
              if (v === undefined) return;
              onRun("insertAt", v, parsedIndex() ?? 0);
            })
          }
          disabled={playing}
        >
          <ChevronsLeft className="size-3.5" /> Sisip di Index
        </Button>

        <Button
          className={cn(opButton, "border bg-card hover:bg-secondary")}
          onClick={() =>
            guard(() => {
              const v = parsedValue();
              if (v === undefined) return;
              onRun("delete", v);
            })
          }
          disabled={playing}
        >
          <Trash2 className="size-3.5" /> Hapus
        </Button>
        <Button
          className={cn(opButton, "border bg-card hover:bg-secondary")}
          onClick={() =>
            guard(() => {
              const v = parsedValue();
              if (v === undefined) return;
              onRun("search", v);
            })
          }
          disabled={playing}
        >
          <Search className="size-3.5" /> Cari
        </Button>
        <Button
          className={cn(opButton, "border bg-secondary hover:bg-accent")}
          onClick={() => guard(() => onRun("reverse"))}
          disabled={playing}
        >
          <RotateCcw className="size-3.5" /> Balik List
        </Button>

        <Button
          variant="outline"
          className={cn(opButton, "border-0 bg-card")}
          onClick={onShowCode}
        >
          <Eye className="size-3.5" /> Kode Python
        </Button>
      </div>

      {/* Baris 2: playback */}
      <div className="flex flex-wrap items-center gap-2.5">
        <Button
          variant="outline"
          size="icon"
          className="size-10 rounded-lg bg-card shadow-clay-xs clay-press"
          onClick={onStepBack}
          disabled={totalFrames === 0 || cursor === 0}
          aria-label="Langkah mundur"
        >
          <SkipBack className="size-4" />
        </Button>
        <Button
          className="size-10 rounded-lg bg-primary text-primary-foreground shadow-clay-primary clay-press hover:bg-primary/90"
          onClick={onTogglePlay}
          disabled={totalFrames === 0}
          aria-label={playing ? "Jeda" : "Putar"}
        >
          {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
        </Button>
        <Button
          variant="outline"
          size="icon"
          className="size-10 rounded-lg bg-card shadow-clay-xs clay-press"
          onClick={onStepForward}
          disabled={totalFrames === 0 || cursor >= totalFrames - 1}
          aria-label="Langkah maju"
        >
          <SkipForward className="size-4" />
        </Button>

        <div className="ml-1 flex min-w-44 items-center gap-2 rounded-lg border bg-card px-3.5 py-1.5 shadow-clay-inset">
          <span className="text-[10px] font-semibold tracking-wide text-muted-foreground uppercase">
            Laju
          </span>
          <Slider
            value={[speed]}
            min={0.5}
            max={4}
            step={0.5}
            onValueChange={(vals) => onSpeedChange(vals[0])}
            className="w-28"
            aria-label="Kecepatan animasi"
          />
          <span className="w-8 text-right text-[10px] font-semibold tabular-nums text-muted-foreground">
            {speed}×
          </span>
        </div>

        <div className="rounded-lg border bg-card px-3.5 py-2 font-mono text-[11px] font-medium text-muted-foreground shadow-clay-inset tabular-nums">
          frame {totalFrames === 0 ? 0 : cursor + 1}/{totalFrames}
        </div>

        <Button
          variant="outline"
          className={cn(opButton, "bg-card")}
          onClick={onUndo}
          disabled={!canUndo || playing}
        >
          <Undo2 className="size-3.5" /> Undo
        </Button>
        <Button
          variant="outline"
          className={cn(opButton, "bg-card")}
          onClick={onReset}
          disabled={playing}
        >
          Contoh Awal
        </Button>
        <Button
          variant="outline"
          className={cn(opButton, "border-destructive/30 bg-card text-destructive hover:bg-destructive/10")}
          onClick={onClear}
          disabled={playing}
        >
          Kosongkan
        </Button>
      </div>
    </div>
  );
}
