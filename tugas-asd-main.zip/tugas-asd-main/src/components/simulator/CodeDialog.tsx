import { useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Check, Copy, FileCode2 } from "lucide-react";
import linkedlistPy from "../../../flask-app/linkedlist.py?raw";
import appPy from "../../../flask-app/app.py?raw";
import templateHtml from "../../../flask-app/templates/index.html?raw";

interface FileTab {
  name: string;
  label: string;
  code: string;
}

const FILES: FileTab[] = [
  { name: "linkedlist.py", label: "linkedlist.py", code: linkedlistPy },
  { name: "app.py", label: "app.py", code: appPy },
  { name: "templates/index.html", label: "index.html", code: templateHtml },
];

export function CodeDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [active, setActive] = useState(0);
  const [copied, setCopied] = useState(false);

  const current = FILES[active];
  const lines = useMemo(() => current.code.replace(/\n$/, "").split("\n"), [current]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(current.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      // Clipboard API tidak tersedia — abaikan.
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl gap-0 overflow-hidden rounded-2xl border bg-card p-0 shadow-clay sm:max-w-2xl">
        <DialogHeader className="border-b border-border/60 px-6 pt-6 pb-4">
          <DialogTitle className="flex items-center gap-2 text-lg font-semibold">
            <FileCode2 className="size-5 text-primary" />
            Kode Sumber — Proyek Flask
          </DialogTitle>
          <DialogDescription>
            Kode Python lengkap tugas ini (folder <code className="rounded bg-muted px-1 font-mono text-[11px]">flask-app/</code>), ditampilkan persis seperti file aslinya.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-between gap-3 border-b border-border/60 bg-muted/50 px-4 py-2.5">
          <div className="flex flex-wrap gap-1.5">
            {FILES.map((f, i) => (
              <button
                key={f.name}
                onClick={() => setActive(i)}
                className={cn(
                  "rounded-lg px-3.5 py-1.5 font-mono text-[11px] font-medium transition-colors",
                  i === active
                    ? "bg-primary text-primary-foreground"
                    : "bg-card text-muted-foreground hover:text-foreground",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
          <Button
            variant="outline"
            size="sm"
            className="rounded-lg bg-card shadow-clay-xs"
            onClick={copy}
          >
            {copied ? (
              <Check className="size-3.5 text-chart-4" />
            ) : (
              <Copy className="size-3.5" />
            )}
            {copied ? "Tersalin" : "Salin"}
          </Button>
        </div>

        <div className="max-h-[55vh] overflow-auto bg-[#1e2230] p-4">
          <pre className="font-mono text-[12px] leading-5">
            {lines.map((line, i) => (
              <div key={i} className="flex">
                <span className="w-9 shrink-0 text-right text-white/25 select-none tabular-nums">
                  {i + 1}
                </span>
                <code
                  className={cn(
                    "pl-3 whitespace-pre",
                    /class |def |@app\.route|return |import |from /.test(line)
                      ? "text-[#9fb8ff]"
                      : "text-[#d6dae6]",
                  )}
                >
                  {line || " "}
                </code>
              </div>
            ))}
          </pre>
        </div>
      </DialogContent>
    </Dialog>
  );
}
