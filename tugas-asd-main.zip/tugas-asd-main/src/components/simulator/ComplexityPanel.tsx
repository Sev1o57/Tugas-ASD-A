import { cn } from "@/lib/utils";
import { Clock } from "lucide-react";

const ROWS = [
  {
    op: "insert_head",
    bigO: "O(1)",
    desc: "Cukup geser pointer head — tanpa traversal.",
    tone: "good" as const,
  },
  {
    op: "insert_tail",
    bigO: "O(n)",
    desc: "Menelusuri sampai node terakhir sebelum menyambung.",
    tone: "lin" as const,
  },
  {
    op: "insert_at",
    bigO: "O(n)",
    desc: "Menelusuri sampai posisi index yang dituju.",
    tone: "lin" as const,
  },
  {
    op: "delete",
    bigO: "O(n)",
    desc: "Menelusuri sambil mencocokkan nilai, lalu melewatkan node.",
    tone: "lin" as const,
  },
  {
    op: "search",
    bigO: "O(n)",
    desc: "Tidak ada lompatan acak — cek satu per satu.",
    tone: "lin" as const,
  },
  {
    op: "reverse",
    bigO: "O(n)",
    desc: "Membalik arah setiap pointer sekali jalan.",
    tone: "lin" as const,
  },
];

const TONES = {
  good: "bg-chart-4/15 text-foreground",
  lin: "bg-chart-3/20 text-foreground",
};

export function ComplexityPanel({ className }: { className?: string }) {
  return (
    <div className={cn("flex h-full flex-col", className)}>
      <div className="flex items-center justify-between px-5 pt-4">
        <h3 className="flex items-center gap-1.5 text-sm font-semibold">
          <Clock className="size-4 text-primary" />
          Kompleksitas Waktu
        </h3>
        <span className="rounded-full border bg-muted px-2.5 py-0.5 font-mono text-[10px] font-medium text-muted-foreground">
          Big-O
        </span>
      </div>
      <ul className="flex-1 space-y-2 overflow-y-auto px-5 pt-3 pb-5">
        {ROWS.map((r) => (
          <li
            key={r.op}
            className="flex items-center gap-3 rounded-xl border bg-card px-3 py-2 shadow-clay-xs"
          >
            <span
              className={cn(
                "w-12 shrink-0 rounded-md px-1 py-1 text-center font-mono text-[11px] font-semibold",
                TONES[r.tone],
              )}
            >
              {r.bigO}
            </span>
            <div className="min-w-0">
              <p className="truncate font-mono text-[12px] font-bold">{r.op}</p>
              <p className="truncate text-[11px] text-muted-foreground">{r.desc}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
