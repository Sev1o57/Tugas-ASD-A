import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { NodeState } from "@/lib/linkedList";

const STATE_STYLES: Record<NodeState, string> = {
  idle: "border-border/60 bg-card text-foreground shadow-clay-xs",
  active: "border-amber-300/70 bg-chart-3/25 text-foreground ring-2 ring-chart-3/40",
  compare: "border-amber-300/70 bg-chart-3/25 text-foreground ring-2 ring-chart-3/40",
  new: "border-primary/40 bg-primary text-primary-foreground shadow-clay-primary",
  removing: "border-destructive/40 bg-destructive/10 text-destructive shadow-clay-xs",
  found: "border-emerald-300/70 bg-chart-4/15 text-foreground ring-2 ring-chart-4/40",
  ghost: "border-primary/30 bg-primary/15 text-primary",
};

const STATE_LABEL: Partial<Record<NodeState, string>> = {
  active: "current",
  compare: "bandingkan",
  new: "node baru",
  removing: "dihapus",
  found: "ditemukan",
  ghost: "baru",
};

export function NodeChip({ node, index }: { node: FrameNodeLike; index: number }) {
  const isGhost = node.state === "ghost";
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.5, y: -14 }}
      animate={{ opacity: isGhost ? 0.75 : 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.5, y: 14 }}
      transition={{ type: "spring", stiffness: 380, damping: 26 }}
      className={cn(
        "relative flex min-w-20 shrink-0 flex-col items-center rounded-xl border px-3 py-2.5",
        STATE_STYLES[node.state],
      )}
    >
      <span className="text-lg leading-none font-semibold tabular-nums">
        {node.value}
      </span>
      <span className="mt-1 text-[10px] leading-none font-medium opacity-75">
        index {index}
      </span>
      {STATE_LABEL[node.state] && (
        <span className="absolute -top-2.5 rounded-full border bg-card px-2 py-0.5 text-[9px] font-semibold text-foreground shadow-clay-xs">
          {STATE_LABEL[node.state]}
        </span>
      )}
    </motion.div>
  );
}

export function ArrowLink() {
  return (
    <div className="flex shrink-0 flex-col items-center text-muted-foreground/70" aria-hidden>
      <span className="text-lg leading-none">→</span>
      <span className="text-[9px] font-medium tracking-wide">next</span>
    </div>
  );
}

export function NullTag() {
  return (
    <div
      className="flex shrink-0 flex-col items-center rounded-xl border border-dashed border-border bg-secondary px-3.5 py-2.5"
      aria-hidden
    >
      <span className="text-sm leading-none font-semibold text-muted-foreground">NULL</span>
      <span className="mt-1 text-[9px] leading-none font-medium text-muted-foreground/70">
        None
      </span>
    </div>
  );
}

export function HeadTag() {
  return (
    <div className="flex shrink-0 flex-col items-center" aria-hidden>
      <div className="rounded-full border bg-secondary px-3 py-1 text-[10px] font-semibold text-secondary-foreground shadow-clay-xs">
        head →
      </div>
    </div>
  );
}

// Bentuk minimal yang dibutuhkan chip — kompatibel dengan FrameNode.
interface FrameNodeLike {
  id: string;
  value: number;
  state: NodeState;
}
