// Engine animasi operasi linked list — langkah demi langkah, mengikuti alur
// logika implementasi Python pada flask-app/linkedlist.py.
// Setiap operasi menghasilkan daftar frame; tiap frame berisi snapshot node,
// fungsi + nomor baris aktif (untuk highlight pseudocode), dan narasi.

export type NodeState =
  | "idle"
  | "active"
  | "compare"
  | "new"
  | "removing"
  | "found"
  | "ghost";

export interface FrameNode {
  id: string;
  value: number;
  state: NodeState;
}

export type FnName =
  | "insert_head"
  | "insert_tail"
  | "insert_at"
  | "delete"
  | "search"
  | "reverse";

export interface Frame {
  nodes: FrameNode[];
  fn: FnName;
  /** Nomor baris lokal di dalam blok pseudocode fungsi. */
  line: number;
  message: string;
}

export interface OpResult {
  ok: boolean;
  frames: Frame[];
  summary: string;
}

let uid = 0;
const nextId = () => `n${++uid}`;

const freeze = (
  fn: FnName,
  nodes: FrameNode[],
  line: number,
  message: string,
): Frame => ({
  fn,
  line,
  message,
  nodes: nodes.map((n) => ({ ...n })),
});

const resetStates = (nodes: FrameNode[]): FrameNode[] =>
  nodes.map((n) => ({ ...n, state: "idle" as NodeState }));

// ---------------------------------------------------------------------------
// insert_head — O(1)
// ---------------------------------------------------------------------------
export function insertHead(nodes: FrameNode[], value: number): OpResult {
  const frames: Frame[] = [];
  let list = resetStates(nodes);
  const ghost: FrameNode = { id: nextId(), value, state: "ghost" };

  frames.push(
    freeze("insert_head", list, 2, `new_node = Node(${value}) — node baru diciptakan di memori.`),
  );
  if (list.length > 0) {
    frames.push(
      freeze("insert_head", list, 3, `new_node.next = self.head — node baru menunjuk ke head lama (${list[0].value}).`),
    );
  } else {
    frames.push(
      freeze("insert_head", list, 3, `new_node.next = self.head — head masih None, jadi next menunjuk ke NULL.`),
    );
  }

  list = [ghost, ...list];
  frames.push(
    freeze("insert_head", list, 4, `self.head = new_node — head sekarang menunjuk node ${value}.`),
  );
  list = list.map((n) => (n.id === ghost.id ? { ...n, state: "new" as NodeState } : n));
  frames.push(
    freeze("insert_head", list, 4, `Node ${value} menjadi head baru. Operasi selesai dalam O(1).`),
  );

  return { ok: true, frames, summary: `Node ${value} disisipkan di head.` };
}

// ---------------------------------------------------------------------------
// insert_tail — O(n)
// ---------------------------------------------------------------------------
export function insertTail(nodes: FrameNode[], value: number): OpResult {
  const frames: Frame[] = [];
  let list = resetStates(nodes);
  const ghost: FrameNode = { id: nextId(), value, state: "ghost" };

  frames.push(freeze("insert_tail", list, 2, `new_node = Node(${value}) — node baru diciptakan.`));

  if (list.length === 0) {
    frames.push(freeze("insert_tail", list, 3, `self.head is None — list kosong.`));
    list = [ghost];
    frames.push(
      freeze("insert_tail", list, 4, `self.head = new_node — node ${value} menjadi head sekaligus tail.`),
    );
    return { ok: true, frames, summary: `Node ${value} disisipkan di tail.` };
  }

  frames.push(freeze("insert_tail", list, 5, `current = self.head — mulai menelusuri dari node ${list[0].value}.`));
  for (let i = 0; i < list.length; i++) {
    const marked = list.map((n, j) =>
      j === i ? { ...n, state: "active" as NodeState } : { ...n, state: "idle" as NodeState },
    );
    if (i < list.length - 1) {
      frames.push(
        freeze("insert_tail", marked, 7, `while current.next — next ada, jadi current maju (melewati ${list[i].value}).`),
      );
    } else {
      frames.push(
        freeze("insert_tail", marked, 6, `while current.next — berhenti: node ${list[i].value} adalah node terakhir (next = None).`),
      );
    }
  }

  list = [...list, ghost];
  frames.push(
    freeze("insert_tail", list, 8, `current.next = new_node — node terakhir kini menunjuk node ${value}.`),
  );
  list = list.map((n) => (n.id === ghost.id ? { ...n, state: "new" as NodeState } : n));
  frames.push(freeze("insert_tail", list, 8, `Node ${value} menjadi tail baru. Kompleksitas O(n).`));

  return { ok: true, frames, summary: `Node ${value} disisipkan di tail.` };
}

// ---------------------------------------------------------------------------
// insert_at — O(n)
// ---------------------------------------------------------------------------
export function insertAt(nodes: FrameNode[], value: number, index: number): OpResult {
  const frames: Frame[] = [];
  let list = resetStates(nodes);

  if (index < 0 || index > list.length) {
    frames.push(
      freeze("insert_at", list, 7, `prev is None — index ${index} di luar jangkauan (0..${list.length}) → IndexError.`),
    );
    return {
      ok: false,
      frames,
      summary: `Index ${index} tidak valid untuk list berisi ${list.length} node.`,
    };
  }

  if (index === 0) {
    frames.push(freeze("insert_at", list, 2, `index == 0 → delegasi ke insert_head(data).`));
    const headRes = insertHead(list, value);
    return {
      ok: true,
      frames: [...frames, ...headRes.frames],
      summary: `Node ${value} disisipkan pada index 0 (head).`,
    };
  }

  const ghost: FrameNode = { id: nextId(), value, state: "ghost" };
  frames.push(freeze("insert_at", list, 4, `prev = self.head — mulai dari node ${list[0].value}.`));

  for (let i = 1; i < index; i++) {
    const marked = list.map((n, j) =>
      j === i - 1 ? { ...n, state: "active" as NodeState } : { ...n, state: "idle" as NodeState },
    );
    frames.push(
      freeze("insert_at", marked, 6, `for _ in range(${index - 1}) — langkah ${i} dari ${index - 1}, prev maju ke ${list[i].value}.`),
    );
  }
  frames.push(
    freeze(
      "insert_at",
      list.map((n, j) => (j === index - 1 ? { ...n, state: "active" as NodeState } : n)),
      6,
      `Berhenti di node ${list[index - 1].value} — ini posisi prev untuk index ${index}.`,
    ),
  );

  list = [...list.slice(0, index), ghost, ...list.slice(index)];
  frames.push(
    freeze("insert_at", list, 9, `new_node.next = prev.next — node ${value} menunjuk ke ${list[index + 1]?.value ?? "None"}.`),
  );
  frames.push(
    freeze("insert_at", list, 10, `prev.next = new_node — node ${list[index - 1].value} kini menunjuk node ${value}.`),
  );
  list = list.map((n) => (n.id === ghost.id ? { ...n, state: "new" as NodeState } : n));
  frames.push(
    freeze("insert_at", list, 10, `Node ${value} tersisip pada index ${index}. Kompleksitas O(n).`),
  );

  return { ok: true, frames, summary: `Node ${value} disisipkan pada index ${index}.` };
}

// ---------------------------------------------------------------------------
// delete — O(n)
// ---------------------------------------------------------------------------
export function deleteValue(nodes: FrameNode[], value: number): OpResult {
  const frames: Frame[] = [];
  let list = resetStates(nodes);

  if (list.length === 0) {
    frames.push(freeze("delete", list, 3, `self.head is None — list kosong, tidak ada yang bisa dihapus.`));
    return { ok: false, frames, summary: `List kosong — data ${value} tidak ditemukan.` };
  }

  if (list[0].value === value) {
    frames.push(
      freeze("delete", list, 4, `self.head.data == data — data ${value} berada di head.`),
    );
    list = list.map((n, j) => (j === 0 ? { ...n, state: "removing" as NodeState } : n));
    frames.push(freeze("delete", list, 5, `self.head = self.head.next — head digeser ke node berikutnya.`));
    const removed = list[0].value;
    list = list.slice(1);
    frames.push(freeze("delete", list, 5, `Node ${removed} dilepas dari rantai (dihapus).`));
    return { ok: true, frames, summary: `Node ${removed} dihapus dari list.` };
  }

  frames.push(freeze("delete", list, 7, `prev = head, current = head.next — mulai membandingkan dari node ke-2.`));

  const idx = list.findIndex((n) => n.value === value);
  if (idx === -1) {
    for (let i = 1; i < list.length; i++) {
      const marked = list.map((n, j) =>
        j === i ? { ...n, state: "compare" as NodeState } : { ...n, state: "idle" as NodeState },
      );
      frames.push(
        freeze("delete", marked, 10, `Bandingkan current.data (${list[i].value}) dengan ${value} — belum cocok, maju terus.`),
      );
    }
    frames.push(freeze("delete", list, 15, `current == None — data ${value} tidak ada di list, return False.`));
    return { ok: false, frames, summary: `Data ${value} tidak ditemukan — tidak ada yang dihapus.` };
  }

  for (let i = 1; i <= idx; i++) {
    const marked = list.map((n, j) =>
      j === i ? { ...n, state: i === idx ? ("found" as NodeState) : ("compare" as NodeState) } : { ...n, state: "idle" as NodeState },
    );
    if (i < idx) {
      frames.push(
        freeze("delete", marked, 10, `Bandingkan current.data (${list[i].value}) dengan ${value} — belum cocok, maju terus.`),
      );
    } else {
      frames.push(freeze("delete", marked, 11, `current.data == data — node ${value} ditemukan di index ${i}!`));
    }
  }

  list = list.map((n, j) => (j === idx ? { ...n, state: "removing" as NodeState } : n));
  frames.push(
    freeze("delete", list, 12, `prev.next = current.next — node ${list[idx - 1].value} melompati node ${value}.`),
  );
  const removed = list[idx].value;
  list = list.filter((_, j) => j !== idx);
  frames.push(freeze("delete", list, 12, `Node ${removed} dilepas dari rantai. Kompleksitas O(n).`));

  return { ok: true, frames, summary: `Node ${removed} dihapus dari list.` };
}

// ---------------------------------------------------------------------------
// search — O(n)
// ---------------------------------------------------------------------------
export function search(nodes: FrameNode[], value: number): OpResult {
  const frames: Frame[] = [];
  const list = resetStates(nodes);

  if (list.length === 0) {
    frames.push(freeze("search", list, 3, `while current — head None, loop tidak jalan.`));
    frames.push(freeze("search", list, 7, `return False — list kosong, ${value} pasti tidak ada.`));
    return { ok: false, frames, summary: `List kosong — ${value} tidak ditemukan.` };
  }

  let found = false;
  for (let i = 0; i < list.length; i++) {
    const marked = list.map((n, j) =>
      j === i ? { ...n, state: "compare" as NodeState } : { ...n, state: "idle" as NodeState },
    );
    frames.push(
      freeze("search", marked, 4, `Iterasi ${i + 1}: cek current.data (${list[i].value}) == ${value}?`),
    );
    if (list[i].value === value) {
      found = true;
      const hit = list.map((n, j) => (j === i ? { ...n, state: "found" as NodeState } : n));
      frames.push(freeze("search", hit, 5, `Cocok — return True, ${value} berada di index ${i}.`));
      break;
    }
  }

  if (!found) {
    frames.push(freeze("search", list, 7, `Sampai None tanpa cocok — return False. ${value} tidak ada di list.`));
    return { ok: false, frames, summary: `${value} tidak ditemukan setelah ${list.length} iterasi.` };
  }

  return { ok: true, frames, summary: `${value} ditemukan di dalam list.` };
}

// ---------------------------------------------------------------------------
// reverse — O(n)
// ---------------------------------------------------------------------------
export function reverse(nodes: FrameNode[]): OpResult {
  const frames: Frame[] = [];
  let list = resetStates(nodes);

  if (list.length <= 1) {
    frames.push(freeze("reverse", list, 3, `List dengan ≤ 1 node — pembalikan tidak mengubah apa pun.`));
    return { ok: true, frames, summary: `List terlalu pendek untuk dibalik.` };
  }

  frames.push(freeze("reverse", list, 2, `prev = None, current = self.head — mulai dari node ${list[0].value}.`));

  const original = [...list];
  for (let i = 0; i < original.length; i++) {
    list = list.map((n, j) =>
      j === i ? { ...n, state: "active" as NodeState } : { ...n, state: "idle" as NodeState },
    );
    frames.push(
      freeze(
        "reverse",
        list,
        4,
        `Iterasi ${i + 1}: next_node = current.next (${original[i + 1]?.value ?? "None"}) lalu current.next dibalik ke prev (${original[i - 1]?.value ?? "None"}).`,
      ),
    );
    const target = original.length - 1 - i;
    if (target !== i) {
      const swapped = [...list];
      const [item] = swapped.splice(i, 1);
      swapped.splice(target, 0, item);
      list = swapped;
    }
    frames.push(freeze("reverse", list, 5, `prev = current, current = next_node — lanjut ke node berikutnya.`));
  }

  list = resetStates(list);
  frames.push(
    freeze("reverse", list, 7, `self.head = prev — head baru menunjuk node ${list[0].value}. List berhasil dibalik.`),
  );

  return { ok: true, frames, summary: `List berhasil dibalik.` };
}

// ---------------------------------------------------------------------------
// Pseudocode per fungsi (penomoran lokal — sinkron dengan frame.line)
// ---------------------------------------------------------------------------
export interface PseudocodeBlock {
  fn: FnName;
  label: string;
  code: string[];
}

export const PSEUDOCODE: PseudocodeBlock[] = [
  {
    fn: "insert_head",
    label: "insert_head() · O(1)",
    code: [
      "def insert_head(self, data):",
      "    new_node = Node(data)",
      "    new_node.next = self.head",
      "    self.head = new_node",
    ],
  },
  {
    fn: "insert_tail",
    label: "insert_tail() · O(n)",
    code: [
      "def insert_tail(self, data):",
      "    new_node = Node(data)",
      "    if self.head is None:",
      "        self.head = new_node",
      "        return",
      "    current = self.head",
      "    while current.next:",
      "        current = current.next",
      "    current.next = new_node",
    ],
  },
  {
    fn: "insert_at",
    label: "insert_at() · O(n)",
    code: [
      "def insert_at(self, index, data):",
      "    if index == 0:",
      "        self.insert_head(data)",
      "        return",
      "    prev = self.head",
      "    for _ in range(index - 1):",
      "        prev = prev.next",
      "    if prev is None:",
      "        raise IndexError(...)",
      "    new_node = Node(data)",
      "    new_node.next = prev.next",
      "    prev.next = new_node",
    ],
  },
  {
    fn: "delete",
    label: "delete() · O(n)",
    code: [
      "def delete(self, data):",
      "    if self.head is None:",
      "        return False",
      "    if self.head.data == data:",
      "        self.head = self.head.next",
      "        return True",
      "    prev = self.head",
      "    current = self.head.next",
      "    while current:",
      "        if current.data == data:",
      "            prev.next = current.next",
      "            return True",
      "        prev, current = current, current.next",
      "    return False",
    ],
  },
  {
    fn: "search",
    label: "search() · O(n)",
    code: [
      "def search(self, data):",
      "    current = self.head",
      "    while current:",
      "        if current.data == data:",
      "            return True",
      "        current = current.next",
      "    return False",
    ],
  },
  {
    fn: "reverse",
    label: "reverse() · O(n)",
    code: [
      "def reverse(self):",
      "    prev, current = None, self.head",
      "    while current:",
      "        next_node = current.next",
      "        current.next = prev",
      "        prev, current = current, next_node",
      "    self.head = prev",
    ],
  },
];
