// File ini mengatur provider autentikasi aplikasi (email OTP dan tamu/guest).
// Tambahkan provider baru hanya jika memang diperlukan dan sesuai dokumentasi Convex Auth.

import { convexAuth } from "@convex-dev/auth/server";
import { Anonymous } from "@convex-dev/auth/providers/Anonymous";
import { emailOtp } from "./auth/emailOtp";


export const { auth, signIn, signOut, store, isAuthenticated } = convexAuth({
  providers: [emailOtp, Anonymous],
});