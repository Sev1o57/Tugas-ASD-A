import { Email } from "@convex-dev/auth/providers/Email";
import { RandomReader, generateRandomString } from "@oslojs/crypto/random";

export const emailOtp = Email({
  id: "email-otp",
  maxAge: 60 * 15, // 15 menit
  // Fungsi ini boleh asynchronous
  async generateVerificationToken() {
    const random: RandomReader = {
      read(bytes: Uint8Array) {
        crypto.getRandomValues(bytes);
      },
    };
    const alphabet = "0123456789";
    return generateRandomString(random, alphabet, 6);
  },
  async sendVerificationRequest({ identifier: email, token }) {
    const apiKey = process.env.RESEND_API_KEY;
    const from = process.env.RESEND_FROM_EMAIL ?? "onboarding@resend.dev";

    if (!apiKey) {
      throw new Error(
        "Variabel lingkungan RESEND_API_KEY belum diatur, sehingga kode verifikasi tidak dapat dikirim. " +
          "Masuk dengan tombol tamu (guest) untuk mencoba aplikasi tanpa email.",
      );
    }

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: email,
        subject: `Kode verifikasi ASD Project: ${token}`,
        text: `Kode verifikasi Anda: ${token}\n\nKode berlaku selama 15 menit.`,
      }),
    });

    if (!response.ok) {
      throw new Error(
        `Gagal mengirim email verifikasi (status ${response.status}). ` +
          "Periksa RESEND_API_KEY dan RESEND_FROM_EMAIL. " +
          "Alternatif: gunakan tombol tamu (guest) untuk masuk tanpa email.",
      );
    }
  },
});
