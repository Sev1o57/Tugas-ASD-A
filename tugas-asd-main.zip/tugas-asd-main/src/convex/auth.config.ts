import type { AuthConfig } from "convex/server";

export default {
  providers: [
    // Provider Convex Auth standar untuk login aplikasi ini (email OTP dan
    // tamu/guest, lihat src/convex/auth.ts). Deployment menerbitkan JWT-nya
    // sendiri (iss = CONVEX_SITE_URL, tanpa header `kid`) yang divalidasi
    // lewat OIDC discovery di `${domain}/.well-known/openid-configuration`,
    // yang disajikan oleh auth.addHttpRoutes() di convex/http.ts. Jangan
    // mengubah entri ini menjadi `type: "customJwt"` — jalur tersebut
    // menolak token tanpa header `kid`, sehingga proses login akan gagal
    // dan halaman tidak akan pernah selesai memuat.
    {
      domain: process.env.CONVEX_SITE_URL!,
      applicationID: "convex",
    },
  ],
} satisfies AuthConfig;
